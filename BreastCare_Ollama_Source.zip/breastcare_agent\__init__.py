"""BreastCare educational agent integration."""
